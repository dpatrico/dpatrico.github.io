//This is the javascript to enable the lightbox to work in my html
$document.ready(function () {
    $('#gallery a').lightBox();
});